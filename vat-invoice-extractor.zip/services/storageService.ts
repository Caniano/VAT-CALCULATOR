
import { User, StoredBill } from '../types';

/**
 * NOTE: This is a mock storage service using localStorage for demonstration purposes.
 * It is NOT secure and should not be used in a production environment.
 * In a real application, you would use a secure backend with a database and proper authentication.
 */

const DB_KEY = 'vat-invoice-app-db';

interface Database {
    users: Record<string, { passwordHash: string; bills: StoredBill[] }>;
    currentUserEmail: string | null;
}

// Helper to get the database from localStorage
const getDb = (): Database => {
    try {
        const dbString = localStorage.getItem(DB_KEY);
        if (dbString) {
            return JSON.parse(dbString) as Database;
        }
    } catch (error) {
        console.error("Error reading from localStorage", error);
    }
    // Return a default structure if DB doesn't exist or is corrupt
    return { users: {}, currentUserEmail: null };
};

// Helper to save the database to localStorage
const saveDb = (db: Database) => {
    try {
        localStorage.setItem(DB_KEY, JSON.stringify(db));
    } catch (error) {
        console.error("Error writing to localStorage", error);
    }
};

// Initialize with a default user if none exists
export const initialize = () => {
    const db = getDb();
    if (!db.users['user@example.com']) {
        db.users['user@example.com'] = {
            // In a real app, this would be a securely generated hash
            passwordHash: 'password123', 
            bills: [],
        };
        saveDb(db);
    }
};

// --- User Functions ---

export const loginUser = (email: string, pass: string): Promise<User | null> => {
    return new Promise((resolve) => {
        setTimeout(() => { // Simulate network delay
            const db = getDb();
            const userData = db.users[email];
            if (userData && userData.passwordHash === pass) {
                db.currentUserEmail = email;
                saveDb(db);
                resolve({ email });
            } else {
                resolve(null);
            }
        }, 500);
    });
};

export const logoutUser = () => {
    const db = getDb();
    db.currentUserEmail = null;
    saveDb(db);
};

export const getCurrentUser = (): User | null => {
    const db = getDb();
    if (db.currentUserEmail) {
        return { email: db.currentUserEmail };
    }
    return null;
};


// --- Bill Functions ---

export const getBillsForUser = (email: string): StoredBill[] => {
    const db = getDb();
    const bills = db.users[email]?.bills || [];
    // Return sorted by most recent first
    return bills.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
};

export const addBillForUser = (email: string, bill: StoredBill): StoredBill[] => {
    const db = getDb();
    if (db.users[email]) {
        db.users[email].bills.unshift(bill); // Add to the beginning of the array
        saveDb(db);
        return getBillsForUser(email); // Return the updated list
    } else {
        throw new Error("User not found to add bill.");
    }
};

export const deleteBillForUser = (email: string, billId: string): StoredBill[] => {
     const db = getDb();
    if (db.users[email]) {
        db.users[email].bills = db.users[email].bills.filter(b => b.id !== billId);
        saveDb(db);
        return getBillsForUser(email); // Return the updated list
    } else {
        throw new Error("User not found to delete bill.");
    }
};