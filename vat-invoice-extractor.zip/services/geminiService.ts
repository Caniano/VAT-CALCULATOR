
import { GoogleGenAI, Type } from "@google/genai";
import { BillData } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const billSchema = {
    type: Type.OBJECT,
    properties: {
        subtotal: {
            type: Type.NUMBER,
            description: 'The subtotal amount before any taxes or discounts are applied. This is often labeled "Subtotal" or is the sum of line items. If not found, set to null.',
        },
        tax: {
            type: Type.NUMBER,
            description: 'The total tax amount (e.g., VAT) listed on the bill. If not explicitly found, set to null.',
        },
        total: {
            type: Type.NUMBER,
            description: 'The final, grand total amount payable on the bill, inclusive of tax. This is often labeled "Total" or "Grand Total". If it cannot be found, set to 0.',
        },
        currency: {
            type: Type.STRING,
            description: 'The currency symbol or code (e.g., AED, $, ₹, SAR).',
        },
        fullText: {
            type: Type.STRING,
            description: 'The entire text extracted from the bill, preserving line breaks.',
        },
    },
    required: ["subtotal", "tax", "total", "currency", "fullText"],
};


export const extractBillInfo = async (imageBase64: string, mimeType: string): Promise<BillData> => {
    try {
        const imagePart = {
            inlineData: {
                data: imageBase64,
                mimeType: mimeType,
            },
        };

        const prompt = `
            You are an expert financial data extraction AI. Your task is to analyze the provided receipt image with extreme precision. 
            The text could be in English, Arabic, Hindi, or Urdu.

            Extract the following financial details into a structured JSON format:
            1.  **Subtotal**: The amount BEFORE tax. This is often labeled 'Subtotal', 'Amount', or is the sum of line items. If this value is present, it is the most important for our calculation. Set to \`null\` if not found.
            2.  **Tax/VAT**: The tax amount. Set to \`null\` if not found.
            3.  **Total**: The final, grand total amount, INCLUSIVE of tax. This is often labeled 'Total', 'Grand Total', 'Amount Due', or 'Payable'. This is the second most important value if Subtotal is not available.
            4.  **Currency**: The currency symbol or code (e.g., AED, $, ₹, SAR).
            5.  **fullText**: All text from the receipt.

            **CRITICAL INSTRUCTIONS FOR ACCURACY:**
            -   **PRIORITIZE SUBTOTAL:** Your primary goal is to find the 'Subtotal' (pre-tax amount). The user's calculation depends on this value.
            -   **DECIMAL PRECISION:** Financial amounts almost always have two decimal places. Be extremely careful. For example, \`2,068.50\` is correct, \`20685\` or \`206.850\` is likely wrong. If you see \`98.5\`, extract it as \`98.5\`, not \`985\`.
            -   **COMMON SENSE CHECK:** Analyze the relationship between the numbers. A 'Tax' amount is usually a small fraction (e.g., 5-20%) of the 'Subtotal'. An extracted tax of \`985\` on a subtotal of \`1970\` is illogical. The correct value is more likely \`98.5\`.
            -   **VERIFY CALCULATIONS:** If all three values (subtotal, tax, total) are present, check if \`subtotal + tax\` is close to \`total\`. This helps confirm your extraction is correct.
        `;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: { parts: [imagePart, { text: prompt }] },
            config: {
                responseMimeType: "application/json",
                responseSchema: billSchema,
            },
        });

        const jsonText = response.text.trim();
        const parsedData = JSON.parse(jsonText) as BillData;
        
        return parsedData;

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to extract bill information from the image.");
    }
};