
import React, { useState, useRef, useCallback } from 'react';
import { UploadIcon, CameraIcon, ClearIcon } from './Icons';

interface ImageUploaderProps {
    onImageUpload: (file: File) => void;
    isProcessing: boolean;
    onClear: () => void;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageUpload, isProcessing, onClear }) => {
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [isDragging, setIsDragging] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const cameraInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const previewUrl = URL.createObjectURL(file);
            setImagePreview(previewUrl);
            onImageUpload(file);
        }
    };
    
    const handleClear = () => {
        setImagePreview(null);
        if (fileInputRef.current) fileInputRef.current.value = "";
        if (cameraInputRef.current) cameraInputRef.current.value = "";
        onClear();
    };

    const onDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(true);
    };
    const onDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
    };
    const onDragOver = (e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
    };
    const onDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
        const file = e.dataTransfer.files?.[0];
        if (file && file.type.startsWith('image/')) {
            const previewUrl = URL.createObjectURL(file);
            setImagePreview(previewUrl);
            onImageUpload(file);
        }
    }, [onImageUpload]);

    return (
        <div className="w-full">
            {imagePreview ? (
                <div className="relative w-full group">
                    <img src={imagePreview} alt="Bill preview" className="w-full h-auto max-h-96 object-contain rounded-lg shadow-lg" />
                    {!isProcessing && (
                         <button
                            onClick={handleClear}
                            className="absolute top-3 right-3 bg-black bg-opacity-60 text-white p-2 rounded-full hover:bg-opacity-80 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-white"
                            aria-label="Clear image"
                        >
                            <ClearIcon className="h-6 w-6" />
                        </button>
                    )}
                </div>
            ) : (
                <div 
                    onDragEnter={onDragEnter}
                    onDragLeave={onDragLeave}
                    onDragOver={onDragOver}
                    onDrop={onDrop}
                    className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300 ${isDragging ? 'border-primary bg-blue-50 dark:bg-primary/10 scale-105' : 'border-slate-300 dark:border-slate-600 hover:border-primary-focus bg-slate-50 dark:bg-slate-800/50'}`}
                >
                    <input
                        ref={fileInputRef}
                        id="file-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleFileChange}
                        disabled={isProcessing}
                    />
                    <div className="flex flex-col items-center justify-center text-slate-500 dark:text-slate-400">
                        <label htmlFor="file-upload" className="flex flex-col items-center cursor-pointer p-4 rounded-lg transition-colors hover:bg-slate-100 dark:hover:bg-slate-700">
                            <UploadIcon className="h-12 w-12 mb-4 text-slate-400 dark:text-slate-500" />
                            <p className="font-semibold text-lg mb-2 text-slate-700 dark:text-slate-300">Drag & drop your bill here</p>
                            <p className="text-sm">or click to browse</p>
                        </label>

                        <div className="flex items-center text-slate-400 dark:text-slate-500 w-full max-w-xs my-6">
                            <div className="flex-grow border-t border-slate-300 dark:border-slate-600"></div>
                            <span className="flex-shrink mx-4 text-xs font-semibold tracking-wider">OR</span>
                            <div className="flex-grow border-t border-slate-300 dark:border-slate-600"></div>
                        </div>

                        <label htmlFor="camera-upload" className="inline-flex items-center px-6 py-2 bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors cursor-pointer shadow-sm border border-slate-300 dark:border-slate-600 font-medium">
                            <CameraIcon className="h-5 w-5 mr-2" />
                            Use Camera
                        </label>
                         <input
                            ref={cameraInputRef}
                            id="camera-upload"
                            type="file"
                            accept="image/*"
                            capture="environment"
                            className="hidden"
                            onChange={handleFileChange}
                            disabled={isProcessing}
                        />
                    </div>
                </div>
            )}
        </div>
    );
};