
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { ErrorIcon, UserIcon } from './Icons';

const Auth: React.FC = () => {
    const [email, setEmail] = useState('user@example.com');
    const [password, setPassword] = useState('password123');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const { login } = useAuth();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setLoading(true);
        try {
            const user = await login(email, password);
            if (!user) {
                setError('Invalid email or password. Please try again.');
            }
        } catch (err: any) {
            setError(err.message || 'An unexpected error occurred.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-xl p-8 md:p-12 transition-shadow duration-300 max-w-md mx-auto animate-fade-in">
            <div className="text-center mb-8">
                <div className="inline-block p-4 bg-primary/10 rounded-full">
                    <UserIcon className="h-12 w-12 mx-auto text-primary" />
                </div>
                <h2 className="mt-4 text-3xl font-bold text-slate-800 dark:text-white">Welcome Back!</h2>
                <p className="text-slate-500 dark:text-slate-400">Sign in to continue to your dashboard.</p>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-6">
                {error && (
                    <div className="p-3 bg-red-100 dark:bg-red-900/50 border-l-4 border-red-500 text-red-700 dark:text-red-200 rounded-md flex items-center text-sm">
                        <ErrorIcon className="h-5 w-5 mr-3 flex-shrink-0" />
                        <span>{error}</span>
                    </div>
                )}

                 <div className="p-4 bg-blue-50 dark:bg-slate-700/50 border-l-4 border-primary text-primary dark:text-blue-300 rounded-md text-sm">
                    <p className="font-bold mb-1">Demo Credentials:</p>
                    <p>Email: <strong className="text-slate-700 dark:text-white">user@example.com</strong></p>
                    <p>Password: <strong className="text-slate-700 dark:text-white">password123</strong></p>
                </div>

                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                        Email Address
                    </label>
                    <div className="mt-1">
                        <input
                            id="email"
                            name="email"
                            type="email"
                            autoComplete="email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full px-4 py-2 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-primary-focus focus:border-primary-focus"
                        />
                    </div>
                </div>

                <div>
                    <label htmlFor="password" className="block text-sm font-medium text-slate-700 dark:text-slate-300">
                        Password
                    </label>
                    <div className="mt-1">
                        <input
                            id="password"
                            name="password"
                            type="password"
                            autoComplete="current-password"
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full px-4 py-2 bg-slate-100 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md shadow-sm placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-primary-focus focus:border-primary-focus"
                        />
                    </div>
                </div>

                <div>
                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-gradient-to-r from-primary to-blue-600 hover:from-primary-hover hover:to-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-focus disabled:bg-slate-400 disabled:cursor-not-allowed transition-all transform hover:scale-105"
                    >
                        {loading ? 'Signing In...' : 'Sign In'}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default Auth;