
import React, { useState, useEffect, useCallback } from 'react';
import { StoredBill, BillData } from '../types';
import { useAuth } from '../context/AuthContext';
import * as storage from '../services/storageService';
import { extractBillInfo } from '../services/geminiService';
import { ImageUploader } from './ImageUploader';
import { BillResult } from './BillResult';
import { Loader } from './Loader';
import { ErrorIcon, PlusIcon, ChevronLeftIcon, TrashIcon, DocumentTextIcon } from './Icons';

// Utility to convert file to base64
const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => {
            const result = reader.result as string;
            resolve(result.split(',')[1]); // remove the "data:mime/type;base64," prefix
        };
        reader.onerror = error => reject(error);
    });
};

const Dashboard: React.FC = () => {
    const { currentUser } = useAuth();
    const [bills, setBills] = useState<StoredBill[]>([]);
    const [selectedBill, setSelectedBill] = useState<StoredBill | null>(null);
    const [view, setView] = useState<'list' | 'new' | 'details'>('list');
    
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (currentUser) {
            const userBills = storage.getBillsForUser(currentUser.email);
            setBills(userBills);
        }
    }, [currentUser]);

    const handleProcessNewBill = useCallback(async (file: File) => {
        if (!file || !currentUser) return;
        
        setIsLoading(true);
        setError(null);

        const VAT_RATE = 0.05; // 5% VAT

        try {
            const base64Image = await fileToBase64(file);
            const extractedData = await extractBillInfo(base64Image, file.type);
            
            let finalData: BillData | null = null;

            if (extractedData) {
                // Priority 1: Use the subtotal if it's valid. This is the most accurate method.
                if (extractedData.subtotal && extractedData.subtotal > 0) {
                    const subtotal = extractedData.subtotal;
                    const tax = subtotal * VAT_RATE;
                    const total = subtotal + tax;

                    finalData = {
                        ...extractedData,
                        subtotal,
                        tax,
                        total,
                    };
                } 
                // Priority 2: Fallback to the total if subtotal is missing.
                else if (extractedData.total && extractedData.total > 0) {
                    const total = extractedData.total;
                    const subtotal = total / (1 + VAT_RATE);
                    const tax = total - subtotal;
                    
                    finalData = {
                        ...extractedData,
                        subtotal,
                        tax,
                        total,
                    };
                }
            }

            if (finalData) {
                const newBill: StoredBill = {
                    id: crypto.randomUUID(),
                    imageBase64: base64Image,
                    mimeType: file.type,
                    fileName: file.name,
                    createdAt: new Date().toISOString(),
                    billData: finalData,
                };

                const updatedBills = storage.addBillForUser(currentUser.email, newBill);
                setBills(updatedBills);
                setSelectedBill(newBill);
                setView('details');

            } else {
                setError("Could not extract a valid subtotal or total amount from the bill. Please try another image.");
            }

        } catch (err) {
            console.error("Error processing bill:", err);
            setError("An unexpected error occurred. Please check your API key and try again.");
        } finally {
            setIsLoading(false);
        }
    }, [currentUser]);

    const handleViewBill = (bill: StoredBill) => {
        setSelectedBill(bill);
        setView('details');
    };

    const handleDeleteBill = (billId: string) => {
        if (!currentUser) return;
        if (window.confirm('Are you sure you want to delete this bill?')) {
            const updatedBills = storage.deleteBillForUser(currentUser.email, billId);
            setBills(updatedBills);
        }
    };
    
    const reset = () => {
        setError(null);
        setIsLoading(false);
        setView('list');
    };
    
    const BackButton = () => (
         <button onClick={() => setView('list')} className="flex items-center mb-6 text-sm font-medium text-primary hover:underline">
            <ChevronLeftIcon className="h-5 w-5 mr-1 transform rotate-90" /> Back to Bill History
        </button>
    );

    const renderContent = () => {
        switch(view) {
            case 'new':
                return (
                    <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-xl p-6 md:p-10">
                         <BackButton />
                        <ImageUploader onImageUpload={handleProcessNewBill} isProcessing={isLoading} onClear={reset}/>
                        {isLoading && <Loader />}
                         {error && !isLoading && (
                            <div className="mt-8 p-4 bg-red-100 dark:bg-red-900/50 border-l-4 border-red-500 text-red-700 dark:text-red-200 rounded-lg flex items-center">
                                <ErrorIcon className="h-6 w-6 mr-3"/>
                                <div>
                                    <p className="font-bold">Error Processing Bill</p>
                                    <p>{error}</p>
                                </div>
                            </div>
                        )}
                    </div>
                );
            case 'details':
                if (!selectedBill) return null;
                return (
                     <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-xl p-6 md:p-10">
                        <BackButton />
                        <div className="grid md:grid-cols-2 gap-8 items-start">
                            <div className="w-full">
                                <img 
                                    src={`data:${selectedBill.mimeType};base64,${selectedBill.imageBase64}`} 
                                    alt={selectedBill.fileName}
                                    className="w-full h-auto object-contain rounded-lg shadow-lg border border-slate-200 dark:border-slate-700"
                                />
                            </div>
                            <BillResult billData={selectedBill.billData} />
                        </div>
                    </div>
                );
            case 'list':
            default:
                return (
                    <div>
                        <div className="flex justify-between items-center mb-8">
                            <h2 className="text-3xl font-bold text-slate-800 dark:text-white">My Bills</h2>
                            <button 
                                onClick={() => setView('new')}
                                className="inline-flex items-center px-5 py-2.5 bg-gradient-to-r from-primary to-blue-600 text-white rounded-lg hover:from-primary-hover hover:to-blue-700 transition-all shadow-lg transform hover:scale-105"
                            >
                                <PlusIcon className="h-5 w-5 mr-2" />
                                <span className="font-semibold">Scan New Bill</span>
                            </button>
                        </div>

                        {bills.length > 0 ? (
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {bills.map(bill => (
                                    <div key={bill.id} className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden group transition-all duration-300 hover:shadow-xl hover:scale-105">
                                        <div className="relative">
                                            <img 
                                                src={`data:${bill.mimeType};base64,${bill.imageBase64}`} 
                                                alt={bill.fileName}
                                                className="w-full h-48 object-cover cursor-pointer"
                                                onClick={() => handleViewBill(bill)}
                                            />
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                                        </div>
                                        <div className="p-4 relative">
                                            <div className="flex justify-between items-start">
                                                 <div>
                                                    <p className="text-xl font-bold text-primary dark:text-secondary">
                                                        {bill.billData.currency} {bill.billData.total.toFixed(2)}
                                                    </p>
                                                    <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                                                        {new Date(bill.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                                                    </p>
                                                </div>
                                                <button onClick={() => handleDeleteBill(bill.id)} className="text-slate-400 hover:text-red-500 p-2 -mr-2 -mt-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity" aria-label="Delete bill">
                                                    <TrashIcon className="h-5 w-5" />
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                             <div className="bg-white dark:bg-slate-800/50 text-center py-20 px-8 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl">
                                <DocumentTextIcon className="h-16 w-16 mx-auto text-slate-400" />
                                <h3 className="mt-4 text-xl font-medium text-slate-800 dark:text-white">No Bills Found</h3>
                                <p className="mt-2 text-slate-500 dark:text-slate-400">Click "Scan New Bill" to get started and extract your first invoice.</p>
                            </div>
                        )}
                    </div>
                );
        }
    };

    return <div className="animate-fade-in">{renderContent()}</div>;
};

export default Dashboard;