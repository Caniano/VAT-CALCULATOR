
import React from 'react';
import { BillData } from '../types';
import { ChevronLeftIcon } from './Icons';

interface BillResultProps {
    billData: BillData;
}

const ResultCard: React.FC<{ title: string; value: string; currency?: string; isTotal?: boolean }> = ({ title, value, currency, isTotal = false }) => (
    <div className={`p-6 rounded-xl shadow-lg text-center transition-transform transform hover:scale-105 ${isTotal ? 'bg-gradient-to-br from-primary to-blue-700 text-white' : 'bg-blue-50 dark:bg-slate-700'}`}>
        <h3 className={`text-sm font-semibold uppercase tracking-wider ${isTotal ? 'text-blue-200' : 'text-slate-500 dark:text-slate-400'}`}>{title}</h3>
        <p className={`text-4xl font-bold mt-2 ${isTotal ? '' : 'text-primary dark:text-secondary'}`}>
            {currency && value !== 'N/A' && <span className="text-2xl align-top mr-1 opacity-70">{currency}</span>}
            {value}
        </p>
    </div>
);

export const BillResult: React.FC<BillResultProps> = ({ billData }) => {
    return (
        <div className="w-full animate-fade-in">
            <h2 className="text-2xl font-bold text-center mb-6 text-slate-700 dark:text-slate-300">Extraction Complete!</h2>
            <div className="grid grid-cols-1 gap-6">
                 <ResultCard 
                    title="Subtotal" 
                    value={billData.subtotal?.toFixed(2) ?? 'N/A'}
                    currency={billData.currency}
                />
                <ResultCard 
                    title="VAT / Tax (5%)" 
                    value={billData.tax?.toFixed(2) ?? 'N/A'} 
                    currency={billData.currency} 
                />
                 <ResultCard 
                    title="Grand Total" 
                    value={billData.total.toFixed(2)} 
                    currency={billData.currency}
                    isTotal
                />
            </div>
            <FullTextAccordion fullText={billData.fullText} />
        </div>
    );
};

const FullTextAccordion: React.FC<{ fullText: string }> = ({ fullText }) => {
    const [isOpen, setIsOpen] = React.useState(false);
    return (
        <div className="mt-8 border border-slate-200 dark:border-slate-700 rounded-lg overflow-hidden">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full flex justify-between items-center p-4 bg-slate-50 dark:bg-slate-700/50 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors focus:outline-none focus:ring-2 focus:ring-primary-focus"
                aria-expanded={isOpen}
                aria-controls="full-text-content"
            >
                <span className="font-semibold text-slate-700 dark:text-slate-200">View Full Extracted Text</span>
                <ChevronLeftIcon className={`w-6 h-6 transform transition-transform text-slate-500 ${isOpen ? '-rotate-180' : 'rotate-0'}`} />
            </button>
            {isOpen && (
                <div id="full-text-content" className="p-4 bg-white dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700">
                    <pre className="whitespace-pre-wrap text-sm text-slate-600 dark:text-slate-300 font-mono bg-slate-100 dark:bg-slate-900/50 p-4 rounded-md">{fullText}</pre>
                </div>
            )}
        </div>
    );
};