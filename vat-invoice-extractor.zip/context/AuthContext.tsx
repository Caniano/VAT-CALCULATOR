import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import * as storage from '../services/storageService';
import { User } from '../types';

interface AuthContextType {
    currentUser: User | null;
    loading: boolean;
    login: (email: string, pass: string) => Promise<User | null>;
    logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // On app start, check for a logged-in user in storage
        storage.initialize(); // Ensure default user exists
        const user = storage.getCurrentUser();
        if (user) {
            setCurrentUser(user);
        }
        setLoading(false);
    }, []);

    const login = async (email: string, pass: string): Promise<User | null> => {
        const user = await storage.loginUser(email, pass);
        setCurrentUser(user);
        return user;
    };

    const logout = () => {
        storage.logoutUser();
        setCurrentUser(null);
    };

    const value = {
        currentUser,
        loading,
        login,
        logout,
    };

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};
